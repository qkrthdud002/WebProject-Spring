package com.subject.board.boardsubject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardsubjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardsubjectApplication.class, args);
	}

}
