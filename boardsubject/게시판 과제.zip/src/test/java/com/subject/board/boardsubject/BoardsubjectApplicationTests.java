package com.subject.board.boardsubject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardsubjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
